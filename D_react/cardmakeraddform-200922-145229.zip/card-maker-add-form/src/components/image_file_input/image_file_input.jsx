import React from 'react';
import styles from './image_file_input.module.css';

const ImageFileInput = props => <button>Image</button>;

export default ImageFileInput;
